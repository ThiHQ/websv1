# Giới thiệu

Chương trình dùng để tạo một socketServer
Hãy tham khảo bài viết để biết thêm chi tiết tại http://arduino.vn/bai-viet/1523-esp8266-ket-noi-internet-phan-4-ket-noi-internet-cho-du-khong-can-nat-port-khong-can